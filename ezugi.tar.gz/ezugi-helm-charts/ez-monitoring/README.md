## Introduction

The monitoring chart uses Promtheus , Grafana and YACE to monitor the k8s cluster + AWS ALB metrics.

## Installation

...

## Configuration

See [values.yaml] for specific overrides

https://github.com/prometheus-community/helm-charts
https://github.com/grafana/helm-charts
https://github.com/ivx/yet-another-cloudwatch-exporter
