# cluster-autoscaler

## Introduction

The Amazon Elastic Block Store Container Storage Interface (CSI) Driver provides a CSI interface used by Container Orchestrators to manage the lifecycle of Amazon EBS volumes.

## Installation

Choose a value for $REPOSITORY fro mthe table below based on the value of $REGION :

af-south-1	877085696533.dkr.ecr.af-south-1.amazonaws.com/
ap-east-1	800184023465.dkr.ecr.ap-east-1.amazonaws.com/
ap-northeast-1	602401143452.dkr.ecr.ap-northeast-1.amazonaws.com/
ap-northeast-2	602401143452.dkr.ecr.ap-northeast-2.amazonaws.com/
ap-northeast-3	602401143452.dkr.ecr.ap-northeast-3.amazonaws.com/
ap-south-1	602401143452.dkr.ecr.ap-south-1.amazonaws.com/
ap-southeast-1	602401143452.dkr.ecr.ap-southeast-1.amazonaws.com/
ap-southeast-2	602401143452.dkr.ecr.ap-southeast-2.amazonaws.com/
ca-central-1	602401143452.dkr.ecr.ca-central-1.amazonaws.com/
cn-north-1	918309763551.dkr.ecr.cn-north-1.amazonaws.com.cn/
cn-northwest-1	961992271922.dkr.ecr.cn-northwest-1.amazonaws.com.cn/
eu-central-1	602401143452.dkr.ecr.eu-central-1.amazonaws.com/
eu-north-1	602401143452.dkr.ecr.eu-north-1.amazonaws.com/
eu-south-1	590381155156.dkr.ecr.eu-south-1.amazonaws.com/
eu-west-1	602401143452.dkr.ecr.eu-west-1.amazonaws.com/
eu-west-2	602401143452.dkr.ecr.eu-west-2.amazonaws.com/
eu-west-3	602401143452.dkr.ecr.eu-west-3.amazonaws.com/
me-south-1	558608220178.dkr.ecr.me-south-1.amazonaws.com/
sa-east-1	602401143452.dkr.ecr.sa-east-1.amazonaws.com/
us-east-1	602401143452.dkr.ecr.us-east-1.amazonaws.com/
us-east-2	602401143452.dkr.ecr.us-east-2.amazonaws.com/
us-gov-east-1	151742754352.dkr.ecr.us-gov-east-1.amazonaws.com/
us-gov-west-1	013241004608.dkr.ecr.us-gov-west-1.amazonaws.com/
us-west-1	602401143452.dkr.ecr.us-west-1.amazonaws.com/
us-west-2	602401143452.dkr.ecr.us-west-2.amazonaws.com/

Replace $REGION, $REPOSITORY, $CLUSTER_NAME, $USERNAME, $TOKEN with the appropiate values. 

```
 helm repo add --username $USERNAME --password $TOKEN ezugi-helm-charts https://gitlab.com/api/v4/projects/28912748/packages/helm/stable
 helm repo update

 helm upgrade -install aws-ebs-csi-driver ezugi-helm-charts/ez-aws-ebs-csi \
--namespace kube-system \
--set image.repository=$REPOSITORY/eks/aws-ebs-csi-driver \
--set enableVolumeResizing=true \
--set enableVolumeSnapshot=true \
--set controller.extraVolumeTags.cluster_name=$CLUSTER_NAME \
--set controller.region=$REGION


 ## If you want to install a particular version
 helm upgrade -install aws-ebs-csi-driver ezugi-helm-charts/ez-aws-ebs-csi \
--namespace kube-system \
--set image.repository=$REPOSITORY/eks/aws-ebs-csi-driver \
--set enableVolumeResizing=true \
--set enableVolumeSnapshot=true \
--set controller.extraVolumeTags.cluster_name=$CLUSTER_NAME \
--set controller.region=$REGION \
--version=x.x.x
 ```

## Configuration

See [values.yaml](./values.yaml) for specific overrides and the upstream documentation at https://github.com/kubernetes-sigs/aws-ebs-csi-driver/tree/master/charts/aws-ebs-csi-driver).

## Resources
- [aws-ebs-csi home](https://github.com/kubernetes-sigs/aws-ebs-csi-driver)
- [aws-ebs-csi on AWS docs](https://docs.aws.amazon.com/eks/latest/userguide/ebs-csi.html
- [the helm chart](https://github.com/kubernetes-sigs/aws-ebs-csi-driver/tree/master/charts/aws-ebs-csi-driver)
