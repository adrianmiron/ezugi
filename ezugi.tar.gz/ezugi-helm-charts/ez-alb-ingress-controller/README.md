# alb-ingress-controller

## Introduction

AWS Load Balancer Controller is a controller to help manage Elastic Load Balancers for a Kubernetes cluster.

This is a wrapper chart over the [official alb-load-balancer-controller chart](https://github.com/kubernetes-sigs/aws-load-balancer-controller/tree/main/helm/aws-load-balancer-controller).

## Installation

Replace  $CLUSTER_NAME, $USERNAME, $TOKEN with the appropiate values. 

```
 helm repo add --username $USERNAME --password $TOKEN ezugi-helm-charts https://gitlab.com/api/v4/projects/28912748/packages/helm/stable
 helm repo update
 helm -n kube-system upgrade --install alb-ingress-controller ezugi-helm-charts/ez-alb-ingress-controller --set clusterName="$CLUSTER_NAME"

 ## If you want to install a particular version
 helm -n kube-system upgrade --install alb-ingress-controller ezugi-helm-charts/ez-alb-ingress-controller --set clusterName="$CLUSTER_NAME" --version=x.x.x
 ```

## Configuration

See [values.yaml](./values.yaml) for specific overrides and the upstream documentation at [stable/alb-load-balancer-controller](https://github.com/kubernetes-sigs/aws-load-balancer-controller/tree/main/helm/aws-load-balancer-controller).

## Resources
- [alb-load-balancer-controller home](https://github.com/kubernetes-sigs/aws-load-balancer-controller)
- [alb-load-balancer-controller on AWS docs](https://docs.aws.amazon.com/eks/latest/userguide/aws-load-balancer-controller.html)
- [alb-load-balancer-controller how-it-works](https://kubernetes-sigs.github.io/aws-load-balancer-controller/v2.2/how-it-works/)