# cluster-autoscaler

## Introduction

The [cluster-autoscaler](https://github.com/kubernetes/autoscaler/tree/master/cluster-autoscaler) can automatically scale the underlying _AWS EC2 Auto Scaling Group_ up and down by adding or removing nodes.

For Ezugi's' setup auto-discovery of ASGs is used. This means that there is no need to set the `minSize` and `maxSize` both on the ASG an in the cluster-autoscaler. For this to work the cluster nodes need to be tagged with the `k8s.io/cluster-autoscaler/cluster/$CLUSTER_NAME` and `k8s.io/cluster-autoscaler/enabled`.
This is automatically done for all worker groups by setting `autoscaling_enabled` in https://gitlab.com/ez-infra/terraform-modules/tf-module-eks.git/eks.tf).

This is a wrapper chart over the [official cluster-autoscaler chart](https://github.com/helm/charts/tree/master/stable/cluster-autoscaler).

## Installation

Replace $REGION, $CLUSTER_NAME, $USERNAME, $TOKEN with the appropiate values. 

```
 helm repo add --username $USERNAME --password $TOKEN ezugi-helm-charts https://gitlab.com/api/v4/projects/28912748/packages/helm/stable
 helm repo update
 helm -n kube-system upgrade --install cluster-autoscaler ezugi-helm-charts/ez-cluster-autoscaler --set cluster-autoscaler.awsRegion="$REGION" --set cluster-autoscaler.autoDiscovery.clusterName="$CLUSTER_NAME"

 ## If you want to install a particular version
 helm -n kube-system upgrade --install cluster-autoscaler ezugi-helm-charts/ez-cluster-autoscaler --set cluster-autoscaler.awsRegion="$REGION" --set cluster-autoscaler.autoDiscovery.clusterName="$CLUSTER_NAME" --version=x.x.x
 ```

## Configuration

See [values.yaml](./values.yaml) for specific overrides and the upstream documentation at [stable/cluster-autoscaler](https://github.com/helm/charts/tree/master/stable/cluster-autoscaler).

## Resources
- [cluster-autoscaler home](https://github.com/kubernetes/autoscaler/tree/master/cluster-autoscaler)
- [cluster-autoscaler on AWS docs](https://github.com/kubernetes/autoscaler/blob/master/cluster-autoscaler/cloudprovider/aws/README.md#auto-discovery-setup)
- [cluster-autoscaler FAQ](https://github.com/kubernetes/autoscaler/blob/master/cluster-autoscaler/FAQ.md)
- [the helm chart in stable/cluster-autoscaler](https://github.com/helm/charts/tree/master/stable/cluster-autoscaler)
