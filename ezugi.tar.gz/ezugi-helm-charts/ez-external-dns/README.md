# oz-external-dns

## Introduction

Fork of the official Bitnami `external-dns` helm chart .

## Installation

Replace $REGION, $OWNER, $NAME , $USERNAME, $TOKEN with the appropiate values. 

```
 helm repo add --username $USERNAME --password $TOKEN ezugi-helm-charts https://gitlab.com/api/v4/projects/28912748/packages/helm/stable
 helm repo update
 helm upgrade --install external-dns ezugi-helm-charts/ez-external-dns  --namespace kube-system --set aws.region=$REGION --set txtOwnerId="$OWNER-$NAME"

 ## If you want to install a particular version
 helm upgrade --install external-dns ezugi-helm-charts/ez-external-dns  --namespace kube-system --set aws.region=$REGION --set txtOwnerId="$OWNER-$NAME" --version=x.x.x
 ```
## Configuration

See [values.yaml](./values.yaml) and the upstream documentation at https://artifacthub.io/packages/helm/bitnami/external-dns).

## Resources
- [the External DNS home](https://github.com/kubernetes-sigs/external-dns)
- [the helm chart at maintained by Bitnami](https://artifacthub.io/packages/helm/bitnami/external-dns)
