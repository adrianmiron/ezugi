# tf-module-cloudfront-s3

A terraform module for websites hosted through Cloudfront and S3