# tf-module-redis

Terraform module for Redis